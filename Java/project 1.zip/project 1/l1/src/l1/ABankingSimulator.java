package l1;

/*  Name:   Zachary Taylor
Course: CNT 4714 Summer 2022 
Assignment title: Project 1 � Synchronized, Cooperating Threads Under Locking 
Due Date: June 5, 2022 
*/ 

/*
import src.ABankAccount;
import src.depositer;
import src.TheBank;
import src.withdrawer;*/

import l1.ABankAccount;
import l1.depositer;
import l1.TheBank;
import l1.withdrawer;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ABankingSimulator{
public static final int maxAgents = 15;

public static void main(String[] args){
   ExecutorService application = Executors.newFixedThreadPool(maxAgents);
   File file = new File("Flagged-Transaction-Log.txt");
   ABankAccount balance = new ABankAccount();
   balance.setBalance(0);
   
   try {
	  file.createNewFile(); 
   }catch(Exception e) {
	   e.printStackTrace();
   }
   

   


   try {
       System.out.println("Deposit  Agents\t\t\t  Withdrawal  Agents\t\t        Balance");
       System.out.println("---------------\t\t\t  ------------------\t\t---------------------------");

       //initialise threads and names of threads
       for(int i = 1; i < 11; i++){
           if(i < 6){
               application.execute(new depositer(balance, i));
           }
           application.execute(new withdrawer(balance, i));           
       }
   } 
   catch (Exception e) {
       e.printStackTrace();
   }

   application.shutdown();
}


}
