package l1;

/*  Name:   Zachary Taylor
Course: CNT 4714 Summer 2022 
Assignment title: Project 1 � Synchronized, Cooperating Threads Under Locking 
Due Date: June 5, 2022 
*/ 


import java.util.Random;

public class depositer implements Runnable{
//variable initializing
Random rand = new Random();
int moneyIn, sleepTime;
int upperBound = 499;
String nameAgent;
private ABankAccount shared = new ABankAccount();


//constructor
public depositer(ABankAccount in, int name){
   nameAgent = "Agent DT"+ name;
   shared = in;
}

//functionality -> adds money in an infinite loop - sleeps and deposits
public void run() {
   while(true){
       try{
           moneyIn = rand.nextInt(upperBound)+1;
           sleepTime = rand.nextInt(10000);
           shared.deposit(moneyIn, nameAgent);
           Thread.sleep(sleepTime);
       }
       catch(Exception exception){
           exception.printStackTrace();
           System.out.println("Depositer error from depositer.java");
       }
   }
   
}

}
