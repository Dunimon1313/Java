package l1;

/*  Name:   Zachary Taylor
Course: CNT 4714 Summer 2022 
Assignment title: Project 1 � Synchronized, Cooperating Threads Under Locking 
Due Date: June 5, 2022 
*/ 

public interface TheBank {
	//used for putting money into an account
    public abstract void deposit(int amount, String id);
    //used for taking money out
    public abstract void withdraw(int amount, String id);
    //suspicious transactions must be flagged and saved into a separate file - note, type = 1 is deposit and type = 2 is withdrawal
    public abstract void susTran(int amount, String id, int type);
}
