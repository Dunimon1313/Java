package l1;

/*  Name:   Zachary Taylor
Course: CNT 4714 Summer 2022 
Assignment title: Project 1 � Synchronized, Cooperating Threads Under Locking 
Due Date: June 5, 2022 
*/ 




import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import java.time.LocalDate;
import java.time.Instant;


public class ABankAccount implements TheBank{
int balance;
private Lock r = new ReentrantLock();


public void setBalance(int money){
     balance = money;
}

public void deposit(int amount, String id) {
     r.lock();
     try {
          if(amount > 350){
               System.out.println("\n* * * Flagged Transaction - Depositer "+ id +" made a Deposit in Excess of $350.00 USD - See Flagged Transaction Log.\n");
               susTran(amount, id, 1);
          }
          balance = balance + amount;
          System.out.println(id +" deposits $"+ amount +"\t\t\t\t\t\t\t (+) Balance is $"+ balance);
          r.notify();
     } catch (Exception e) {
          System.out.println("Depositing error - > method in ABankAccount.java");
     } finally{
          r.unlock();
     }
}


public void withdraw(int amount, String id) {
     r.lock();
     try {
          if(amount > 75){
               System.out.println("\n* * * Flagged Transaction - Withdrawal "+ id +" made a Withdrawal in Excess of $75.00 USD - See Flagged Transaction Log.\n");
               susTran(amount, id, 2);
          }
          if(amount <= balance){
               balance = balance - amount;
               System.out.println(id +" withdraws $"+ amount +"\t\t\t\t\t\t\t (-) Balance is $"+ balance);
          }   
          else{
        	  System.out.println("Withdrawal Blocked for "+ id +" due to INSUFFICIENT FUNDS");
               r.wait();
          }   
     } catch (Exception e) {
          System.out.println("Withdrawing error - > method in ABankAccount.java");
     } finally{

          r.unlock();
     }
}

//sustran does no decision making beyond file creation, its purpose is to mark the current time in a file that is created initially, and appended for further file input
public void susTran(int amount, String id, int type) {
     LocalDate ts = LocalDate.now();
     try {
          FileWriter myObj = new FileWriter("Flagged-Transaction-Log.txt", true);
               if(type == 1){
                    myObj.append("\n");
                    myObj.append(id +"attempted a deposit of "+amount+" at "+ ts);
                    myObj.append("\n");
                    myObj.flush();
                    myObj.close();
               }
               else{
               //file exists and must be added to 
                    myObj.append("\n\n");
                    myObj.append(id +" attempted a withdrawal of "+amount+" at "+ ts);
                    myObj.append("\n");
                    myObj.flush();
                    myObj.close();
               }
     } 
     catch (Exception e) {
          System.out.println("Transaction log error -> ABankAccount.java");
          e.printStackTrace();
     }
}
}
