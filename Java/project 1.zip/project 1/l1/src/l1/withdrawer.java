package l1;

/*  Name:   Zachary Taylor
Course: CNT 4714 Summer 2022 
Assignment title: Project 1 � Synchronized, Cooperating Threads Under Locking 
Due Date: June 5, 2022 
*/ 


import java.util.Random;

public class withdrawer implements Runnable{
//variable initializing
Random rand = new Random();
int upperBound = 98;
String nameAgent;
private ABankAccount shared = new ABankAccount();

//constructor
public withdrawer(ABankAccount in, int name){
   nameAgent = "Agent WT"+ name;
   shared = in;
}

//functionality -> adds money in an infinite loop - sleeps and deposits
public void run() {
   while(true){
       try{
           shared.withdraw((rand.nextInt(upperBound)+1), nameAgent);
           Thread.sleep(rand.nextInt(5000));  
       }
       catch(Exception e){
           System.out.println("Withdrawal Error from withdrawer.java");
       }
   }
   
}

}
