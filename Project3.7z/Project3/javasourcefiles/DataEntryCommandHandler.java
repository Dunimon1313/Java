
//Imports
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.sql.*;
import com.mysql.cj.jdbc.MysqlDataSource;
import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;



//Database connector class - Purpose: takes a username, password, and input string from the associated .jsp
//and sends the command to the database. Results are converted to an html friendly format and returned to the .jsp
public class DataEntryCommandHandler extends HttpServlet{
    Connection connection = null;

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
        Properties properties = new Properties();
		FileInputStream filein = null;
		MysqlDataSource dataSource = null;
        HttpSession session = request.getSession();
        String message;
        Statement stmt;


        String command = request.getParameter("sqlStatement");
        //configures user settings based on which file is being ran
        String userProp = "dataentry.properties";
        String username = "dataentry";
        String password = "dataentry";
        try {
            filein = new FileInputStream(userProp);
            //load user
            properties.load(filein);
            dataSource = new MysqlDataSource();
            if((username.equals((String)properties.getProperty("MYSQL_DB_USERNAME"))  && (password.equals((String)properties.getProperty("MYSQL_DB_PASSWORD"))))) {
                dataSource.setUrl(properties.getProperty("MYSQL_DB_URL"));
                dataSource.setUser(properties.getProperty("MYSQL_DB_USERNAME"));
                dataSource.setPassword(properties.getProperty("MYSQL_DB_PASSWORD"));
                //establish connection
                connection = dataSource.getConnection();
            }		
            stmt = connection.createStatement();
            //execute commands and return message
            message = sendCommand(username, command, stmt, connection, request);
            session.setAttribute("message", message);
            
            RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/dataentryHome.jsp");
            dispatcher.forward(request, response);
        }catch( SQLException el ) {
            message = "<tr bgcolor=#ff0000><td><font color=#ffffff><b>Error executing the SQL statement:</b><br>" + el.getMessage() + "</tr></td>";
        } catch (FileNotFoundException e1) {
            message = "<tr bgcolor=#ff0000><td><font color=#ffffff><b>Error executing the SQL statement:</b><br>" + e1.getMessage() + "</tr></td>";
        } catch (IOException e1) {
            message = "<tr bgcolor=#ff0000><td><font color=#ffffff><b>Error executing the SQL statement:</b><br>" + e1.getMessage() + "</tr></td>";
        }
    }

    String sendCommand(String username, String command, Statement stmt, Connection connection, HttpServletRequest request){
        String returnToWebsite = null;
        ResultSet myResult = null;
        try {
            String supCom1 = "drop table if exists beforeShipments;";
            String supCom2 = "create table beforeShipments like shipments;";
            String supCom3 = "insert into beforeShipments select * from shipments;";
            String supCom4 = "update suppliers set status = status + 5 where suppliers.snum in (select distinct snum from shipments where shipments.quantity >= 100 and not exists (select * from beforeShipments where shipments.snum = beforeShipments.snum and shipments.pnum = beforeShipments.pnum and shipments.jnum = beforeShipments.jnum and beforeshipments.quantity >= 100) );";
            String supCom5 = "drop table beforeshipments;";
            if(!(command.startsWith("s") || command.startsWith("S"))) {//filters for queries
                if((username == "root")){//if user is root, handles updates
                	if (command.contains("shipment") == true) {//if user is sending a shipment update
                		//creates a backup table
                		stmt.executeUpdate(supCom1);
                    	stmt.executeUpdate(supCom2);
                    	stmt.executeUpdate(supCom3);
                    	//alters shipment table
                    	int dbchanges = stmt.executeUpdate(command);
                    	//checks for differences and alters suppliers table
                        int rowsChanged = stmt.executeUpdate(supCom4);
                        //deletes backup table
                        stmt.executeUpdate(supCom5);
                        if(rowsChanged > 0){//rowsChanged will be > 0 if anything was affected
                            return "<p1>The statement executed successfully.<br>"+ dbchanges +" row(s) affected.<br><br>Business Logic Detected - Updating supplier status<br><br>Business Logic updated "+ 
                            rowsChanged +" supplier status marks.</p1>";
                        }
                        else{
                        	dbchanges = stmt.executeUpdate(command);
                            return "<p1>The statement executed successfully.<br>"+ dbchanges +" row(s) affected.<br><br>Business Logic Not Triggered</p1>";
                        }
                	}
                	else if(username == "client") {//if user is client, handles updates
                		int dbchanges = stmt.executeUpdate(command);
                		return "<p1>The statement executed successfully.<br>"+ dbchanges +" row(s) affected.</p1>";
                	}
                	else if(username == "dataentry") {//if user is data entry
                		//preparess parameters for prepared statement
                		String jn, sn, pn, qn;
                		sn = request.getParameter("snum");
                		pn = request.getParameter("pnum");
                		jn = request.getParameter("jnum");
                		qn = request.getParameter("quantity");
                		//Q will be used to determine if business logic applies
                		int Q = Integer.parseInt(qn);
                    	String updateCom = "insert into shipments(snum,pnum,jnum,quantity) values (?, ?, ?, ?)";
                    	PreparedStatement pstmt = connection.prepareStatement(updateCom);
                    	//sets parameters
                    	pstmt.setString(1, sn);
                    	pstmt.setString(2, pn);
                    	pstmt.setString(3, jn);
                    	pstmt.setString(4, qn);
                    	int dbchanges = pstmt.executeUpdate();
                        if(Q >= 100){
                        	stmt.executeUpdate("update suppliers where snum is "+ sn);
                            return "<p1>The statement executed successfully.<br>"+ dbchanges +" row(s) affected.<br><br>Business Logic Detected - Updating supplier status<br><br>Business Logic updated 1 supplier status marks.</p1>";
                        }
                        else{
                            return "<p1>The statement executed successfully.<br>"+ dbchanges +" row(s) affected.<br><br>Business Logic Not Triggered</p1>";
                        }
                	}
                	else {
                		int dbchanges = stmt.executeUpdate(command);
                        return "<p1>The statement executed successfully.<br>"+ dbchanges +" row(s) affected.<br><br>Business Logic Not Triggered</p1>";
                        }
                	}
            }else {
            		myResult = stmt.executeQuery(command);
                    returnToWebsite = convertResultsetTabletoHTMLTable(myResult);
                    return returnToWebsite;
                }
        } catch (SQLException e1) {
        	String message = "<tr bgcolor=#ff0000><td><font color=#ffffff><b>Error executing the SQL staement:</b><br>" + e1.getMessage() + "</tr></td>";
        	return message;
        }
		return returnToWebsite;
    }



    public static synchronized String convertResultsetTabletoHTMLTable(ResultSet results) throws SQLException{
        StringBuffer htmlRows = new StringBuffer();
        ResultSetMetaData metaData = results.getMetaData();
        int columnCount = metaData.getColumnCount();

        htmlRows.append("table row element <tr>");
        for(int i = 1; i < columnCount; i++){
            htmlRows.append("table data element <td> with column name from the meta data </td>");
        }
        htmlRows.append("</tr>");

        int cnt = 0;
        while(results.next()){
            if(cnt % 2 == 0){
                htmlRows.append("<tr> element of one color");
            }else{
                htmlRows.append("<tr> element of the other color");
            }
            cnt++;
            for(int i = 1; i <= columnCount; i++){
                htmlRows.append("set <td> elements one by one");
            }
        }
        htmlRows.append("</tr>");
        return htmlRows.toString();
    }
}
